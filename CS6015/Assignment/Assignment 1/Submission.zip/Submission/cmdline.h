//
// Created by Tailang  Cao on 1/10/24.
//

#ifndef MSDSCRIPT_CMDLINE_H
#define MSDSCRIPT_CMDLINE_H


void use_arguments(int argc, char **argv) ;


#endif //ASSIGNMENT_CMDLINE_H
