var searchData=
[
  ['nameandtags_0',['NameAndTags',['../struct_catch_1_1_name_and_tags.html',1,'Catch']]],
  ['noncopyable_1',['NonCopyable',['../class_catch_1_1_non_copyable.html',1,'Catch']]],
  ['num_2',['Num',['../class_num.html',1,'Num'],['../class_num.html#a9fce58e650a99ae50f4140ed9c87ec9f',1,'Num::Num()']]]
];
