var searchData=
[
  ['var_0',['Var',['../class_var.html',1,'Var'],['../class_var.html#a55074bc8893872aee61cc3123c1931c9',1,'Var::Var()']]],
  ['void_5ftype_1',['void_type',['../struct_catch_1_1detail_1_1void__type.html',1,'Catch::detail']]]
];
