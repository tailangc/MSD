var searchData=
[
  ['var_0',['Var',['../class_var.html#a55074bc8893872aee61cc3123c1931c9',1,'Var']]]
];
