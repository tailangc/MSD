#ifndef CMDLINE_H
#define CMDLINE_H

void use_arguments(int argc, char* argv[]);

#endif //UNTITLED_CMDLINE_H
